import { returnResult } from '../components/commonFunctions/returnResults';
import { Bootstrap } from '../components';

module.exports = function run(context: any, req: any) {

    Bootstrap.start(context);
    context.log.info("Function true started. Node language worker process working successfully.");
    const data = { true: true };
    return returnResult(context, data);
    
};
