/* Defines common error responses */
export const errors: any = {
    "400_BAD_REQUEST": {
        "errorMessage": "Request was malformed.",
        "errorCode": 400,
        "errorStatus": "Bad request"
    },
    "401_UNAUTHORIZED": {
        "errorMessage": "Invalid Credentials.",
        "errorCode": 401,
        "errorStatus": "Unauthorized"
    },
    "403_FORBIDDEN": {
        "errorMessage": "Attempted to access api/resouce without permissions to it.",
        "errorCode": 403,
        "errorStatus": "Resource forbidden"
    },
    "404_NOT_FOUND": {
        "errorMessage": "The resource specified was not found.",
        "errorCode": 404,
        "errorStatus": "Not found"
    },
    "408_TIMEOUT": {
        "errorMessage": "The request timed out.",
        "errorCode": 408,
        "errorStatus": "Request Timeout"
    },
    "500_INTERNAL_SERVER_ERROR": {
        "errorMessage": "Something went wrong.",
        "errorCode": 500,
        "errorStatus": "Internal Server Error"
    }, "502_BAD_GATEWAY": {
        "errorMessage": "Received invalid response from upstream server.",
        "errorCode": 502,
        "errorStatus": "Bad Gateway"
    }, "503_SERVICE_UNAVAILABLE": {
        "errorMessage": "Service unavailable. The server is currently unable to handle the request.",
        "errorCode": 503,
        "errorStatus": "Service Unavailable"
    }, "504_GATEWAY_TIMEOUT": {
        "errorMessage": "The server, while acting as a gateway or proxy, did not get a response in time.",
        "errorCode": 504,
        "errorStatus": "Gateway Timeout"
    }, "PARSING_TIME_ERROR": {
        "errorMessage": "Couldn't parse time. If it's a valid date and/or time, please try rephrasing or adding a reference point like today, from now, next week/month, am/pm to any datetime.",
        "errorCode": 400,
        "errorStatus": "Bad request"
    }, "MISSING_ACTION_ERROR": {
        "errorMessage": "Request was malformed. Missing or invalid action.",
        "errorCode": 400,
        "errorStatus": "Bad request"
    }, "INPUT_VALIDATOR_ERROR": function (missingParams?: any[], invalidTypes?: any[]) {
        let errorMsg = "Request was malformed.";
        if (missingParams && missingParams.length > 0) {
            errorMsg += ` Missing params: [${missingParams}].`;
        }

        if (invalidTypes && invalidTypes.length > 0) {
            errorMsg += ` Parameters with invalid types: [${invalidTypes}].`;
        }

        return {
            "errorMessage": errorMsg,
            "errorCode": 400,
            "errorStatus": "Bad request"
        };
    }, "errorMapper": function (errorCode: string | number, errorMessage?: string, errorStatus?: string) {
        const code = typeof errorCode === "string" ? parseInt(errorCode) : errorCode;
        let error;
        switch (code) {
            case 400: {
                error = errors["400_BAD_REQUEST"];
            } break;
            case 401: {
                error = errors["401_UNAUTHORIZED"];
            } break;
            case 403: {
                error = errors["403_FORBIDDEN"];
            } break;
            case 404: {
                error = errors["404_NOT_FOUND"];
            } break;
            case 408: {
                error = errors["408_TIMEOUT"];
            } break;
            case 500: {
                error = errors["500_INTERNAL_SERVER_ERROR"];
            } break;
            case 502: {
                error = errors["502_BAD_GATEWAY"];
            } break;
            case 503: {
                error = errors["503_SERVICE_UNAVAILABLE"];
            } break;
            case 504: {
                error = errors["504_GATEWAY_TIMEOUT"];
            } break;
            default: {
                error = errors["500_INTERNAL_SERVER_ERROR"];
            }
        }
        const finalError = {
            "errorMessage": errorMessage ? errorMessage : error.errorMessage,
            "errorCode": error.errorCode,
            "errorStatus": errorStatus ? errorStatus : error.errorStatus
        };
        return finalError;
    }
};
