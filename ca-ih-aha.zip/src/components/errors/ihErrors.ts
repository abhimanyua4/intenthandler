export const standardErrors: any = {
    "IH401.1": {
        "errorMessage": "Error Code: IH401.1 - Missing Application header.",
        "errorCode": "IH401.1",
        "errorStatus": "Unauthorized",
        "Description": "Client did not send Astro-Authorization header in request",
        "errorResolution": "Client needs to send Astro-Authorization header",
        "IHcodeFlag": true
    },
    "IH401.2": {
        "errorMessage": "Error Code: IH401.2 - Malformed DSS header",
        "errorCode": "IH401.2",
        "errorStatus": "Unauthorized",
        "Description": "Header didn't contain expected 'Authorization:Bearer token' format",
        "errorResolution": "Client needs to send header in expected format.",
        "IHcodeFlag": true
    },
    "IH401.3": {
        "errorMessage": "Error Code: IH401.3 - Invalid grant_type",
        "errorCode": "IH401.3",
        "errorStatus": "Unauthorized",
        "Description": "Header didn't contain expected 'bearer' grant_type",
        "errorResolution": "Client needs to send expected 'bearer' grant_type",
        "IHcodeFlag": true
    },
    "IH401.4": {
        "errorMessage": "Error Code: IH401.4 - Error decoding Idam JWT",
        "errorCode": "IH401.4",
        "errorStatus": "Unauthorized",
        "Description": "Invalid JWT was sent",
        "errorResolution": "Send a valid JWT",
        "IHcodeFlag": true
    },
    "IH401.5": {
        "errorMessage": "Error Code: IH401.5 - Error verifying Idam JWT",
        "errorCode": "IH401.5",
        "errorStatus": "Unauthorized",
        "Description": "Invalid JWT was sent",
        "errorResolution": "Send a valid JWT",
        "IHcodeFlag": true
    },
    "IH400.1": {
        "errorMessage": "Error Code: IH400.1 - Missing action",
        "errorCode": "IH400.1",
        "errorStatus": "Bad Request",
        "Description": "Client did not send 'action' parameter in request",
        "errorResolution": "Client needs to send 'action' parameter in request.",
        "IHcodeFlag": true
    },
    "IH400.2": {
        "errorMessage": "Error Code: IH400.2 - Missing or invalid request body",
        "errorCode": "IH400.2",
        "errorStatus": "Bad Request",
        "Description": "Client did not send a request body",
        "errorResolution": "Client needs to send request body",
        "IHcodeFlag": true
    },
    "IH400.3": {
        "errorMessage": "Error Code: IH400.3 - Input validation failed.",
        "errorCode": "IH400.3",
        "errorStatus": "Bad Request",
        "Description": "Input validation against predefined schema failed. Error details underneath",
        "errorResolution": "Request body must adhere to predefined schema",
        "IHcodeFlag": true
    },
    "IH400.4": {
        "errorMessage": "Error Code: IH400.4 - Switch Function error",
        "errorCode": "IH400.4",
        "errorStatus": "Bad Request",
        "Description": "Code failed in try/catch while synchronously executing this function. The error is most likely before any asynchronous calls were made to downstream systems.",
        "errorResolution": "Examine the error given",
        "IHcodeFlag": true
    },
    "IH404.1": {
        "errorMessage": "Error Code: IH404.1 - Action not found",
        "errorCode": "IH404.1",
        "errorStatus": "Not Found",
        "Description": "Client sent 'action' parameter that doesn't exist",
        "errorResolution": "Client needs to send one of the predefined actions in controllers",
        "IHcodeFlag": true
    },
    "IH500": {
        "errorMessage": "Internal Server Error",
        "errorCode": "IH500",
        "errorStatus": "Internal Server Error",
        "Description": "",
        "errorResolution": "",
        "IHcodeFlag": true
    },
    "DSS400": {
        "errorMessage": "",
        "errorCode": "DSS400",
        "errorStatus": "",
        "Description": "Downstream system responded with HTTP 400 / input validation failed",
        "errorResolution": "",
        "IHcodeFlag": true
    },
    "DSS401": {
        "errorMessage": "Unauthorized",
        "errorCode": "DSS401",
        "errorStatus": "Unauthorized",
        "Description": "Downstream system responded with HTTP 401 / user is unauthorized",
        "errorResolution": "",
        "IHcodeFlag": true
    },
    "DSS403": {
        "errorMessage": "Forbidden",
        "errorCode": "DSS403",
        "errorStatus": "Forbidden",
        "Description": "Downstream system responded with HTTP 403 / user does not have permissions",
        "errorResolution": "",
        "IHcodeFlag": true
    },
    "DSS404": {
        "errorMessage": "Not found",
        "errorCode": "DSS404",
        "errorStatus": "Not found",
        "Description": "Downstream system responded with HTTP 404 / the resource specified wasn't found",
        "errorResolution": "",
        "IHcodeFlag": true
    },
    "DSS408": {
        "errorMessage": "Application timeout",
        "errorCode": "DSS408",
        "errorStatus": "Application timeout",
        "Description": "Intent Handler or Downstream system timed out",
        "errorResolution": "",
        "IHcodeFlag": true
    },
    "DSS500": {
        "errorMessage": "Internal Server Error",
        "errorCode": "DSS500",
        "errorStatus": "Internal Server Error",
        "Description": "Downstream system had an error",
        "errorResolution": "",
        "IHcodeFlag": true
    },
    "DSS502": {
        "errorMessage": "Bad gateway",
        "errorCode": "DSS502",
        "errorStatus": "Bad gateway",
        "Description": "There's a likely networking error",
        "errorResolution": "",
        "IHcodeFlag": true
    },
    "DSS503": {
        "errorMessage": "Service unavailable",
        "errorCode": "DSS503",
        "errorStatus": "Service unavailable",
        "Description": "Service is down",
        "errorResolution": "",
        "IHcodeFlag": true
    },
    "DSS504": {
        "errorMessage": "Gateway timeout",
        "errorCode": "DSS504",
        "errorStatus": "Gateway timeout",
        "Description": "Gateway timed out before application started to respond",
        "errorResolution": "",
        "IHcodeFlag": true
    },
    "mapper": function (errCode: string, errMessage?: string, errStatus?: string, errDescription?: string, errResolution?: string) {
        const defaultErrorMessage = "Error Code: " + errCode + " not found";
        const defaulstErrStatus = "Bad error code";
        const defaultDescription = "Bad error code";
        const defaultResolution = "No resolution, use different error code or pass in custom resolution";
        const tempErr = {
            "errorMessage": errMessage || defaultErrorMessage,
            "errorCode": errCode,
            "errorStatus": errStatus || defaulstErrStatus,
            "Description": errDescription || defaultDescription,
            "errorResolution": errResolution || defaultResolution,
            "IHcodeFlag": true
        };

        const err = standardErrors[errCode] || tempErr;
        return err;
        //     switch (errCode) {
        //     case "IH401.1" :{
        //         return standardErrors[]
        //     }
        //     case "IH401.2" :
        //     case "IH401.3" :
        //     case "IH401.4" :
        //     case "IH401.5" :
        //     case "IH400.1" :
        //     case "IH400.2" :
        //     case "IH400.3" :
        //     case "IH400.4" :
        //     case "IH404.1" :
        //     case "IH500" :      
        //     case "DSS400" :
        //     case "DSS401" :
        //     case "DSS403" :
        //     case "DSS404" :
        //     case "DSS408" :
        //     case "DSS500" :
        //     case "DSS502" :
        //     case "DSS503" :
        //     case "DSS504" :
        // }
    }
}
