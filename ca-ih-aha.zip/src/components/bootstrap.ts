const appInsights = require("applicationinsights");
import { Log, LoggingOptions } from 'astro-utilities';
import { standardLog } from './constant/logMessages';

export class Bootstrap {

    public static startFlag: boolean | undefined = undefined;

    static start(context?: any) {
        if (!this.startFlag || typeof this.startFlag === 'undefined') {
            this.startFlag = true;
            this.appInsightSetup();
            this.initlog(context);
            return null;
        } else {
            this.initlog(context);
        }
    }

    static initlog(context: any) {

        let debug_log_enabled: boolean = false;
        let info_log_enabled: boolean = false;
        let warn_log_enabled: boolean = false;
        let error_log_enabled: boolean = false;
        let app_insights_enabled: boolean = false;

        if (process.env["LOG-DEBUG-ENABLED"] === "true") {
            debug_log_enabled = true;
        } else {
            debug_log_enabled = false;
        }
        if (process.env["LOG-INFO-ENABLED"] === "true") {
            info_log_enabled = true;
        } else {
            info_log_enabled = false;
        }
        if (process.env["LOG-WARN-ENABLED"] === "true") {
            warn_log_enabled = true;
        } else {
            warn_log_enabled = false;
        }
        if (process.env["LOG-ERROR-ENABLED"] === "true") {
            error_log_enabled = true;
        } else {
            error_log_enabled = false;
        }
        if (process.env["LOG-APP-INSIGHTS-ENABLED"] === "true") {
            app_insights_enabled = true;
        } else {
            app_insights_enabled = false;
        }

        const options: LoggingOptions = {
            debug_log_enabled: debug_log_enabled,
            info_log_enabled: info_log_enabled,
            warn_log_enabled: warn_log_enabled,
            error_log_enabled: error_log_enabled,
            app_insights_enabled: app_insights_enabled,
            env: process.env["NODE-ENV"]
        };

        if (context.req && context.req.body && context.req.body.sensitiveData === true) {
            context.confidential = true;
            context.sensitiveData = true;
            options.confidential = true;
        }

        if (!context.executionContext) {
            context.executionContext = { functionName: "Unknown functionName" };
        }
        const logger = new Log(context, options);
        context.log = logger.log;

        context.log.info(`${context.executionContext.functionName} Started`, standardLog.mapper("started"));
    }

    static appInsightSetup() {
        appInsights.setup(process.env.APPINSIGHTS_INSTRUMENTATIONKEY)
            .setUseDiskRetryCaching(false)
            .setAutoDependencyCorrelation(true)
            .setAutoCollectRequests(true)
            .setAutoCollectPerformance(true)
            .setAutoCollectExceptions(true)
            .setAutoCollectDependencies(true)
            .setAutoCollectConsole(true)
            .start();
    }

}
