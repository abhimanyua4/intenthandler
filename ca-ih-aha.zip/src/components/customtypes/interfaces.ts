export interface ErrorPayload {
    "errorMessage": string;
    "errorCode": number;
    "errorStatus": string;
}

export interface SalesforceAPIHeaders {
    'Proxy-Authorization': string;
    'apikey': string;
    'apikeysecret': string;
    'client_id': string;
    'client_secret': string;
    'username': string;
    'password': string;
    'Content-Type': string;
}

export interface SalesforceImpersonHeaders {
    "Authorization"?: string;
    'Proxy-Authorization': string;
    'apikey': string;
    'apikeysecret': string;
    'SFDC-Domain': string;
}

export interface FactivaAPIHeaders {
    'Content-Type': string;
}

export interface GepGrpOfClientResponse {
    "name": string;
    "email": string;
    "phone": string | number;
    "address": object;
    "mobilePhone": string | number;
}

export interface ResponseBody {
    "statusCode": string;
    "payload": object;
}

export interface ResponseObject {
    "status": number;
    "body": ResponseBody;
    "headers": object;
}

export interface EmailObject {
    "subject": string;
    "userEmail": string;
    "emails": string[];
    "message": string;
}

export interface CommonDataModel {
    conversationID?: string;
    channel?: {
        name: string;
        deviceType: string;
        deviceID?: string;
        osName?: string;
        osVersion?: string;
        timezone?: string;
    };

    request?: {
        userUtterance: string;
        timestamp: number;
        language: string;
        messageType: string
    };

    user?: {
        profileData: {
            guid: string;
            firstName: string;
            lastName: string;
            email: string;
        };

        currentData?: {
            location: string;
            timezone: string;
            country: string
        };
    };
    NLP?: {
        context?: object | undefined;
        userIntent?: string;
        confidence?: number;
        entityValue?: string;
        parametersRequired?: boolean;
        servingAgent?: string;
        parameteres?: [
            {
                name: string;
                response: string;
                helperType: string;
                helpervalues: string;
                userUtterance: string;
                value: string
            }
        ]
    };
    action?: {
        actionName: string;
        actionStatus: boolean;
    };
    response?: {
        finalResponse?: string | undefined;
        helperType?: string;
        helperValues?: object;
        conversationStatus?: string;
    };
    intentHandlerResponse?: object;
}

export interface AstroModelInterface {
    intentName?: string | undefined;
    version?: string | undefined;
    modelId?: string | undefined;
    astroModel: {
        startEvent?: Array<StartEventInterface>;
        sequenceFlow?: Array<SequenceFlowInterface>;
        userTask?: Array<UserTaskInterface>;
        scriptTask?: Array<ScriptTaskInterface>;
        serviceTask?: Array<ServiceTaskInterface>;
        businessRuleTask?: Array<BusinessRuleTaskInterface>;
        exclusiveGateway?: Array<ExclusiveGatewayInterface>;
        endEvent?: Array<EndEventInterface>;
        subProcess?: Array<SubProcessInterface>
    };
    error: Array<object>;
    warning: Array<object>;
    elementMaster?: object | undefined;
    globalElements?: {
        variableDefinition?: string | undefined
    };
    spacy?: object;
}

export interface StartEventInterface {
    id?: string;
    nextSequence?: [string];
    name?: string;
    utterance?: string;
}

export interface UserTaskInterface {
    id?: string;
    nextSequence?: [string];
    incommingSequence?: [string];
    name?: string;
    responseVariable?: string;
    responseType?: string;
}
export interface SubProcessInterface {
    id?: string;
    nextSequence?: [string];
    incomingSequence?: [string];
    name?: string;
    intentId?: string;
    conversationInputs?: string;
    conversationOutputs?: string;
    outputVariable?: string;
}

export interface ExclusiveGatewayInterface {
    id?: string;
    nextSequence?: [string];
    incommingSequence?: [string];
    name?: string;
}

export interface ScriptTaskInterface {
    id?: string;
    nextSequence?: [string];
    incommingSequence?: [string];
    name?: string;
    isConfidential?: string;
    scriptResponse?: string;
}

export interface EndEventInterface {
    id?: string;
    incommingSequence?: [string];
    name?: string;
    conversationOutputs?: string;
}

export interface ServiceTaskInterface {
    id?: string;
    nextSequence?: [string];
    incommingSequence?: [string];
    name?: string;
    fulfillmentObj?: {
        url?: string | undefined;
        returnVariable?: string | undefined;
        handlerParameters?: object | undefined;
    };
}

export interface SequenceFlowInterface {
    sourceRef?: string;
    targetRef?: string;
    name?: string;
    id?: string;
    condition?: string;
    order?: string;
}

export interface BusinessRuleTaskInterface {
    id?: string;
    nextSequence?: [string];
    incommingSequence?: [string];
    name?: string;
    scriptToExecute?: string;
    intentHandlerResponse?: object;
}

export interface ConversationModelRepoDto {
    modelID: string;
    intentName: string;
    version: string;
    enviourment: string;
    isCurrent: boolean;
    blobName: string;
    blobURL: string;
    uploadedBy: string;
    uploadedDate?: string;
}

export interface TransactionLogs {
    modelID: string;
    intentName: string;
    log: string;
    ingestionStatus: string;
    date?: string;
    repoModelObj: object;
}

export interface ValidInput {
    isValid: boolean;
    missingParams: string[];
    invalidTypes: string[];
}

export interface InsightsResult {
    errors?: any[];
    "gsuite/getMe": object | any;
    "upas/consolidatedHrDetails": object | any;
    "upas/partnerSabbaticalSummary": object | any;
    "upas/partnerDevelopmentAllowance": object | any;
    "finance/getMySnapshotDetails": object | any;
    "finance/getEmployeeRoles": object | any;
    "finance/getMyEconomicsTopTwoRoles": object | any;
    "salesforce/salesforce_get_my_value_stage": object | any;
    "salesforce/openOppMePwc": object | any;
}

export interface Logger {
    log(level: string, msg: string, meta?: any): any;
    verbose(msg: string, meta?: any): any;
    debug(msg: string, meta?: any): any;
    info(msg: string, meta?: any): any;
    warn(msg: string, meta?: any): any;
    error(msg: string, meta?: any): any;
}

export interface Context {
    invocationId: string;
    executionContext: {
        invocationId: string;
        functionName: string;
        functionDirectory: string;
    };
    bindings: {
        req: {
            originalUrl: string;
            method: string;
            query: object;
            headers: object;
            params: object;
        };
    };
    log: any | Function | {
        error: Function;
        warn: Function;
        info: Function;
        verbose: Function;
        metric: Function;
    };
    req: {
        originalUrl: string;
        method: string;
        query: any;
        headers: any;
        params: any | { action: string | any };
        body: any | { action: string | any };
        rawBody: any;
        get: Function;
    };
    bindingData: {
        $request: any;
        action: string | any;
        query: any;
        headers: any;
        req: any;
        sys: { methodName: string, utcNow: Date };
        invocationId: string;
    };
    done: Function;
    res: {
        headers: any;
        body: any;
        raw: Function;
        setHeader: Function;
        getHeader: Function;
        removeHeader: Function;
        end: Function;
        status: Function;
        sendStatus: Function;
        type: Function;
        json: Function;
        send: Function;
        set: Function;
        header: Function;
        get: Function;
    };
}
