export const standardLog: any = {
    "started": {
        "message": 'Function started',
        "code": "IHSTART",
        "Description": "Starting point for code flow entrance",
        "IHcodeFlag": true
    },
    "authenticated": {
        "message": "User authenticated",
        "code": "IHAUTH",
        "Description": "Authentication completed for Intent Handler",
        "IHcodeFlag": true
    },
    "requestReceived": {
        "message": "Request Received",
        "code": "IHREC",
        "Description": "Body included in request. Code being sent to validation",
        "IHcodeFlag": true
    },
    "endpointReached": {
        "message": "Endpoint Reached",
        "code": "IHACTION",
        "Description": "Downstream system being reached",
        "IHcodeFlag": true
    },
    "requestValidated": {
        "message": "Request validated",
        "code": "IHVALID",
        "Description": "Request passed JOI validation. Cleared to execute",
        "IHcodeFlag": true
    },
    "completion": {
        "message": "Function completed",
        "code": "IHCOMP",
        "Description": "Function completed execution successfully.",
        "IHcodeFlag": true
    },
    // "mapper" : function(name?: string)
    "mapper": function (logCategory: string, message?: string, code?: string, description?: string) {
        let log: any = {};
        const temp: any =  {
            "message": "" || message,
            "code": "" || code,
            "Description": "" || description,
            "IHcodeFlag": true
        };
        log = standardLog[logCategory] || temp;
        if (message !== undefined && message !== null && message !== "") {
            log.message = message;
        }
        if (code !== undefined && code !== null && code !== "") {
            log.code = code;
        }
        if (description !== undefined && description !== null && description !== "") {
            log.Description = description;
        }
        return log;
    }
    
};
