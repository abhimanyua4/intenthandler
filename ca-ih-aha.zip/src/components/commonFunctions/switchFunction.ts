import { returnBadRequest } from "./returnResults";
import { errors } from "../errors/errors";
import { standardLog } from "../constant/logMessages";
const Joi = require("joi");

/**
 * @description Switch function that validates input is requestSchema is present
 * And calls the routing/controller in a try/catch/finally block.
 *
 * @export
 * @param {*} context The Azure function's context
 * @param {Controller} controller The Controller/function array object
 * @param {*} requestSchema
 */
export function switchFunctionWithJoiValidation(
    context: any,
    controller: any,
    requestSchema: any
) {
    const req: any = context.req;
    let action: string;

    if (req && req.params && req.params.action) {
        action = req.params.action;
    } else if (req && req.body && req.body.action) {
        action = req.body.action;
    } else {
        context.log.error('Error Code: IH400.1 - Missing action', {
            errorMessage: "Request was malformed.",
            code: "IH400.1",
            description: "Client did not send action property in request",
            resolution: "Client needs to send action property in request",
            errorLocation: __dirname
        });
        context.code = "IH400.1";
        return returnBadRequest(context, errors["MISSING_ACTION_ERROR"]);
    }

    if (req && req.method === "POST" && !req.body) {
        context.log.error('Error Code: IH400.2 - Missing or invalid request body.', {
            errorMessage: "Missing or invalid body.",
            code: "IH400.2",
            description: "Client did not send a request body in POST request",
            resolution: 'Client needs to send  request request body',
            errorLocation: __dirname
        });
        context.code = "IH400.2";
        return returnBadRequest(
            context,
            errors.errorMapper(400, "Missing or invalid body.")
        );
    }

    if (requestSchema && requestSchema[action]) {
        if (!req.body) {
            context.log.error('Error Code: IH400.2 - Missing or invalid request body.', {
                errorMessage: "Missing or invalid body.",
                code: "IH400.2",
                description: "Request with defined request schema did not contain request body",
                resolution: 'Client needs to send request body',
                errorLocation: __dirname
            });
            context.code = "IH400.2";
            return returnBadRequest(
                context,
                errors.errorMapper(400, "Missing or invalid body.")
            );
        }

        const input = Joi.validate(req.body, requestSchema[action]);
        if (input.error) {
            context.log.error('Error Code: IH400.3 - Input validation failed.', {
                errorMessage: "Request was malformed.",
                code: "IH400.3",
                description: "Input validation against predefined schema failed. Error details underneath",
                resolution: 'Request body must adhere to predefined schema.',
                errorLocation: __dirname,
                error: input.error
            });
            context.code = "IH400.3";
            return returnBadRequest(context, errors["400_BAD_REQUEST"]);
        }
    }
    context.log.info(`${!!context.executionContext ? context.executionContext.functionName : "Unknown function"}.${action} Validated`, standardLog.mapper("requestValidated"));
    return switchFunction(context, controller, action);
}

/**
 * @description **DEPRECATED; SWITCH TO NEW FUNCTION**
 * Switch function that calls the routing/controller in a
 * try/catch/finally block.
 *
 * @export
 * @param {*} context The Azure function context
 * @param {Controller} controller The Controller/function array object
 * @param {string} action The action/function to get called
 */
export function switchFunction(context: any, controller: any, action: string) {
    let switchFlag = false;
    const forbiddenActions: any = {
        constructor: 1,
        __defineGetter__: 1,
        __defineSetter__: 1,
        __lookupGetter__: 1,
        __lookupSetter__: 1,
        hasOwnProperty: 1,
        isPrototypeOf: 1,
        propertyIsEnumerable: 1,
        toSource: 1,
        toString: 1,
        toLocaleString: 1,
        watch: 1,
        unwatch: 1,
        valueOf: 1,
        eval: 1
    };
    try {
        if (
            !forbiddenActions[action] &&
            controller[action]
            &&
            typeof controller[action] === "function"
        ) {
            context.action = action;

            context.log.info(`Calling function: controller.${action}();`);
            controller[action]();
            switchFlag = true;
        } else {
            switchFlag = true;
            context.log.error('Error Code: IH404.1 - Action not found', {
                errorMessage: "Request was malformed.",
                code: "IH404.1",
                description: "Client sent action parameter that doesn't exist.",
                resolution: "Client needs to send one of the predefined actions in controllers.",
                errorLocation: __dirname
            });
            context.code = "IH404.1";
            returnBadRequest(context, errors["MISSING_ACTION_ERROR"]);
        }
    } catch (err) {
        context.log.error(
            "Error Code: IH400.4 - Switch Function Error", {
                "errorMessage": `Tried to call controller.${action}(); and failed`,
                "code": "IH400.4",
                "description": "Code failed in try/catch while synchronously executing this function." +
                    "The error is most likely before any asynchronous calls were made to downstream systems.",
                "resolution": "Examine following error",
                "errorLocation": __dirname,
                "error": err
            }
        );
        context.code = "IH400.4";
    } finally {
        if (!switchFlag && !context.finished) {
            returnBadRequest(context, errors.errorMapper(400));
        }
    }
}
