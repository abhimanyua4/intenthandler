/**
 * A common callback function to be binded that returns appropriate
 * callback result
 * @param {Function} callback a callback function
 * @param {any} err the error
 * @param {any} result the result
 * @returns {Function} the callback function containing either the error or the result
 */
export function commonCallback(callback: Function, err: any, result: any): Function {
    if (err) {
        return callback(err, null);
    } else {
        return callback(null, result);
    }
}

/**
 * A common function for promises to be binded to callback functions
 * @param {Promise.resolve} resolve contains the result on success
 * @param {Promise.reject} reject throws an error that needs to be caught
 * @param {any} err the error
 * @param {any} result the result
 * @returns {Function} either the error or the result
 */
export function commonPromiseCallback(resolve: any, reject: any, err: any, result: any): Function {
    if (err) {
        return reject(err);
    } else {
        return resolve(result);
    }
}
