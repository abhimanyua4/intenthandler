const Joi = require("joi");

export const baseRequestSchema = {
    action: Joi.string().trim().regex(/[0-9a-zA-Z_]/).optional(),
    state: Joi.object().keys({
        appSessionUUID: Joi.string().trim().regex(/[0-9a-zA-Z_]/).optional(),
        socketId: Joi.string().trim().regex(/[0-9a-zA-Z_]/),
        conversationId: Joi.string().trim().regex(/[0-9a-zA-Z_]/),
        channelRequestID: Joi.string().trim().regex(/[0-9a-zA-Z_]/)
    }).optional(),
    sensitiveData: Joi.boolean().optional(),
    options: Joi.object().optional()
};
