import { ResponseBody } from '../customtypes/interfaces';
import { errors } from '../errors/errors';
import { standardErrors } from '../errors/ihErrors';
import { standardLog } from '../constant/logMessages';
const headers = {
    'Content-Type': 'application/json',
    'Cache-Control': 'no-cache, no-store, must-revalidate',
    'Pragma': 'no-cache',
    'Expires': '0',
    'Server': 'Intent Handlers',
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains'
};

const successLog = "Function Completed SUCCESS";
const errorLog = "Function Completed ERROR";

/**
 * Common callback function to be binded, for sending response back.
 * Returns a status 200 - OK and the result on success.
 * Returns a status of 400 if the request encounters an error and the error message on failure.
 * @param {any} context the function's context
 * @param {any} error the error
 * @param {any} result the result
 */
export function callbackResult(context: any, error: any, result: any): void {
    if (error) {
        return returnBadRequest(context, error);
    } else {
        return returnResult(context, result);
    }
}

/**
 * Returns a bad request. Equivalent to res.send(). Sends the response and 
 * terminates the function. Accepts a message and an optional status code.
 * Defaults to HTTP 200 - Success
 * @param { Object } context the azure function's context
 * @param { Object | string} message the message to be sent as a response, either a JSON
 * @returns {void} 
 */
export function returnResult(context: any, result: any, statusCode?: string): void {
    if (context.timer) { clearTimeout(context.timer); }
    if (result && result.error) {
        return returnBadRequest(context, result.error);
    }

    if (context.callback) {
        context.finished = true;
        return context.callback(null, result);
    }
    const finalResult: ResponseBody = {
        statusCode: statusCode || 'success',
        payload: result
    };

    const status = 200;

    context.res = {
        status,
        body: finalResult,
        headers
    };
    if (!context.finished) {
        context.log.info(successLog, standardLog.mapper("completion"));
        context.log.verbose(
            "Response sent to client is",
            result
        );
        context.finished = true;
        return context.done();
    }
}

/**
 * Returns a bad request. Equivalent to res.send(). Sends the response and 
 * terminates the function. Accepts a message and an optional status code.
 * Defaults to HTTP 400 - Bad request.
 * @param context the azure function's context
 * @param error the message to be sent as a response
 * @param statusCode optional status code
 */
export function returnBadRequest(context: any, error: any, statusCode?: any): void {
    if (context.timer) {
        clearTimeout(context.timer);
    }

    if (error && error.errorCode && (!error.errorMessage || !error.errorStatus)) {
        if (error.IHcodeFlag) {
            error = standardErrors.mapper(error.errorCode);
        } else {
            error = errors.errorMapper(error.errorCode, error.errorMessage, error.errorStatus);

        }
    }

    if (context.callback) {
        context.finished = true;
        return context.callback(error);
    }

    const finalResult: ResponseBody = {
        statusCode: statusCode || 'error',
        payload: error || errors["400_BAD_REQUEST"]
    };

    const status = error.errorCode || 400;

    context.res = {
        status,
        body: finalResult,
        headers
    };

    if (!context.finished) {
        context.log.error(
            errorLog, {
                "errorMessage": errorLog,
                "code": error.IHcodeFlag ? error.errorCode : (context.code ? context.code : 'DSS' + status),
                "statusCode": status,
                "error": error,
            }
        );
        context.finished = true;
        return context.done();
    }
}

/**
 * Returns a bad request. Equivalent to res.send(). Sends the response and 
 * terminates the function. Accepts a message and an optional status code.
 * Defaults to HTTP 401 - Unauthorized.
 * @param {any} context the azure function's context
 * @param {any} error the message to be sent as a response
 * @param {any | undefined} state an optional parameter that maintains state for the user
 * @returns {void} 
 */
export function returnUnauthorized(context: any, error: any, state?: any, statusCode?: string): void {

    if (context.timer) {
        clearTimeout(context.timer);
    }

    if (error && error.errorCode && (!error.errorMessage || !error.errorStatus)) {
        // this should return new IH error mapper
        error = errors.errorMapper(error.errorCode, error.errorMessage, error.errorStatus);
    }

    if (context.callback) {
        context.finished = true;
        return context.callback(error);
    }

    const finalResult: ResponseBody = {
        statusCode: 'error',
        payload: error || errors["401_UNAUTHORIZED"]
    };

    const status = (error && error.errorCode) ? error.errorCode : 401;
    context.res = {
        status,
        body: finalResult,
        headers
    };

    if (!context.finished) {
        // need to use the new IH error mapper here. 
        context.log.error(
            "returnUnauthorized Error", {
                "errorMessage": errorLog,
                "code": context.code ? context.code : 'DSS' + status,
                "statusCode": status,
                "error": error,
            });
        context.finished = true;
        return context.done();
    }
}
