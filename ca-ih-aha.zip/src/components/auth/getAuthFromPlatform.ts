import * as request from 'request';
import * as xss from 'xss';
/**
 * Given all params, does 2 attempts to retrieve
 * required access token from the platform.
 * 
 * @export
 * @param {*} context the Azure functions' context
 * @param {*} state a state param that persists and gets sent back to platform
 * @param {string} _url the url to which to send the requests to
 * @param {string} intenthandlerId the ID of the intent handler doing the request
 * @returns {Promise<any>} returns a promise
 */
export function getAuthFromPlatform(context: any, state: any, _url: string, intenthandlerId: string): Promise<any> {
    return new Promise((resolve, reject) => {
        const body = {
            state,
            newToken: false,
            intenthandlerId
        };

        const body2 = {
            state,
            newToken: true,
            intenthandlerId
        };

        context.log.verbose('PLATFORM AUTH REQUEST BODY: Attempt 1', body);
        const options: request.Options = {
            url: _url,
            port: 443,
            method: 'POST',
            json: body
        };

        const options2: request.Options = {
            url: _url,
            port: 443,
            method: 'POST',
            json: body2
        };
        tokenPromise(options, context)
            .then((token: string) => {
                context.log.verbose(
                    'PLATFORM AUTH Token Response', {
                        "token": token,
                        "platformAuthStatus": "success",
                        "tokenTry": 1
                    });
                validateToken(token, context)
                    .then((access_token) => {
                        context.log.verbose(
                            'validateTokenResponse', {
                                "token": access_token,
                                "validationStatus": "success",
                                "attempt": 1
                            });
                        resolve(access_token);
                    }, (error: any) => {
                        context.log.error('Token Invalid', { "invalidToken": token, "tokenTry": 1 });
                        tokenPromise(options2, context).then((tokenTwo: string) => {
                            context.log.verbose(
                                'PLATFORM AUTH Token Response', {
                                    "token": tokenTwo,
                                    "platformAuthStatus": "success",
                                    "tokenTry": 2
                                });

                            validateToken(tokenTwo, context).then((access_token) => {
                                context.log.verbose(
                                    'validateTokenResponse', {
                                        "token": access_token,
                                        "validationStatus": "success",
                                        "attempt": 2
                                    });
                                resolve(access_token);
                            }, (err) => {
                                context.log.error(
                                    'New Token Invalid', {
                                        "errorMessage": "Token found was invalid, then Astro generated a new one, which is still invalid",
                                        "invalidToken": token,
                                        "tokenTry": 2
                                    });
                                reject(err);
                            });
                        });
                    });
            }, (err: any) => {

                context.log.info('Attempting Token Generation Again');
                context.log.verbose('PLATFORM AUTH REQUEST BODY: Attempt 2', body2);

                tokenPromise(options, context)
                    .then((token: string) => {
                        context.log.verbose(
                            'PLATFORM AUTH Token Response', {
                                "token": token,
                                "platformAuthStatus": "success",
                                "tokenTry": 3
                            });
                        validateToken(token, context)
                            .then((oauth) => {
                                context.log.verbose(
                                    'validateTokenResponse', {
                                        "token": token,
                                        "validationStatus": "success",
                                        "attempt": 3
                                    });
                                resolve(oauth);
                            }, (error: any) => {
                                context.log.error('User unauthorized', {
                                    "errorMessage": "new token is invalid",
                                    "token": token,
                                    "tokenTry": 3
                                });
                                reject(error);
                            });
                    }, (error: any) => {
                        context.log.error("Token Invalid", {
                            "errorMessage": 'Second attempt to get token from Platform failed',
                            "error": error,
                            "tokenTry": 3
                        });
                        reject(error);
                    });
            });
    });
}

export function tokenPromise(options: any, context: any): any {
    return new Promise((resolve, reject) => {
        const error = { error: "Error retrieving token from Platform" };
        request(options, function (err: any, res: any, result: any) {
            if (err) {
                const errXss = typeof err === "object" ? xss(JSON.stringify(err)) : xss(err);
                context.log.error(
                    "tokenPromise Error", {
                        "errorMessage": `Error getting token from platform ${errXss}`,
                        "errorLocation": __dirname
                    });
                return reject(error);
            }
            if (result && result.status === 'success' && result.requestedToken) {
                return resolve(result.requestedToken);
            }
            return reject(error);
        });
    });
}

/**
 * Validates whether access token for downstream system is valid
 * @param {string} accessToken the refresh token,
 * @param {Function} callback the callback function 
 * @returns callback function containing either an error or the oauth2 client with proper credentials
 */
export function validateToken(accessToken: string, _context: any) {
    return new Promise((resolve, reject) => {
        //add validation request to debug if needed
        return resolve(accessToken);
    });
}
