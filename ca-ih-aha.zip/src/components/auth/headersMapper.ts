import { errors } from "../errors/errors";

/**
 * Given a headers and a mapper object, maps received headers to desired ones.
 * On missing headers, returns message with missing headers.
 * 
 * headers 
 * ===========
 * { "odata-apikey": "abc", "odata-apikeysecret": "def" }
 * ===========
 * 
 * mapperobj
 * ===========
 * { apikey: "odata-apikey", apikeysecret: "odata-apikeysecret" }
 * ===========
 * 
 * mappedHeaders
 * ===========
 * { apikey: "abc", apikeysecret: "def"}
 * ===========
 * @export
 * @param {*} headers the headers received
 * @param {*} mapperObj mapping between the names
 * @returns {(string | object)} either the message with missing headers or the mapped headers
 */
export function headersMapper(headers: any, mapperObj: any): string | object {
    const missingHeaders: any = [];
    const mappedHeaders: any = {};
    Object.keys(mapperObj).forEach((key) => {
        if (!headers[mapperObj[key]] || typeof headers[mapperObj[key]] !== "string")
            missingHeaders.push(mapperObj[key]);
        else mappedHeaders[key] = headers[mapperObj[key]];
    });
    if (missingHeaders.length > 0)
        return "Missing headers: " + missingHeaders;
    return mappedHeaders;
}

/**
 * Given a headers and a mapper object, maps received headers to desired ones.
 * On missing headers, returns message with missing headers.
 * 
 * headers 
 * ===========
 * { "odata-apikey": "abc", "odata-apikeysecret": "def" }
 * ===========
 * 
 * mapperobj
 * ===========
 * { apikey: "odata-apikey", apikeysecret: "odata-apikeysecret" }
 * ===========
 * 
 * mappedHeaders
 * ===========
 * { apikey: "abc", apikeysecret: "def"}
 * ===========
 * @export
 * @param {*} headers the headers received
 * @param {*} mapperObj mapping between the names
 * @returns {(string | object)} either the message with missing headers or the mapped headers
 */
export function mapHeaders(headers: any, mapperObj: any): Promise<any> {
    return new Promise((resolve, reject) => {
        const mapped = headersMapper(headers, mapperObj);
        if (typeof mapped === "string")
            return reject(errors.errorMapper(401, mapped));
        else return resolve(mapped);
    });
}
