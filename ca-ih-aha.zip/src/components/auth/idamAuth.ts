import * as jwt from 'jsonwebtoken';
import { errors } from '../errors/errors';
import { getBearerToken } from './getAuthFromHeader';
import { convertCertificate } from './convertCert';

/**
 * The IdamAuthenticator class deals with verifying jsonwebtokens / id_tokens, issued
 * by IDAM, using its public certificate.
 * 
 * @export
 * @class IdamAuthenticator
 * 
 * For standards' documentation look up
 * @see https://tools.ietf.org/html/rfc7516 -- JWE
 * @see https://tools.ietf.org/html/rfc7517 -- JWK
 * @see https://tools.ietf.org/html/rfc7518 -- JWA
 * @see https://tools.ietf.org/html/rfc7519 -- JWT
 * @see https://jwt.io/
 */
export class IdamAuthenticator {

    /**
     * PKCS8 private certificate format @see https://tools.ietf.org/html/rfc5208 
     * @private
     * @type {string}
     * @memberof IdamAuthenticator
     */
    private readonly certFormat = 'PKCS8';

    /**
     * Placeholder for Idam's formatted public certificate 
     *
     * @private
     * @type {*}
     * @memberof IdamAuthenticator
     */
    private readonly cert: any;

    /**
     * RSASHA256 algorithm for json web signature(JWS) 
     * of a json web token (JWT) using using json web key (JWK)
     * @see https://tools.ietf.org/html/rfc7515
     * @type {string}
     * @private
     * @memberof IdamAuthenticator
     */
    private readonly algorithm = 'RS256';

    /* Azure function context */
    private readonly context: any;

    /**
     * Idam's X509 PEM encoded public certificate retrieved from x5c JWK. 
     * https://fedsvc-stage.pwc.com/ofisids/api/jwks
     * Needs to be changed once every few years
     *
     * @private
     * @type {string}
     * @memberof IdamAuthenticator
     */
    private readonly idamPublicCert: string = process.env['IDAM-PUBLIC-CERT'] as string;

    /**
     * Field for holding the user after his credentials get authenticated
     *
     * @private
     * @type {User} //TODO: create user object type based on claims from Idam
     * @memberof IdamAuthenticator
     */
    private user: any;

    /**
     * Placeholder for user's base64 encoded id_token/JWT once verified.
     *
     * @private
     * @type {string}
     * @memberof IdamAuthenticator
     */
    private id_token: any;

    /**
     * Creates an instance of IdamAuthenticator.
     * @param {*} context
     * @memberof IdamAuthenticator
     */
    constructor(context: any) {
        this.context = context;
        this.cert = convertCertificate(context, this.idamPublicCert);
    }

    /**
     * Function for checking oauth2 authorization header for Bearer JWT signed by Idam.
     * Binds logger to context.log currently.
     *
     * @param {*} headers the req.headers object
     * @param {*} context the azure function context
     * @returns {Promise<any>} returns a promise
     * @memberof IdamAuthenticator
     */
    public platformAuthorization(headers: any, context: any): Promise<any> {

        return new Promise((resolve, reject) => {

            if (!headers || !headers["astro-authorization"]) {
                const missingHeader = "Missing Astro-Authorization header.";
                context.log.error("IH401.1 " + missingHeader, {
                    errorMessage: missingHeader,
                    code: "IH401.1",
                    description: "Client did not send Astro-Authorization header in request",
                    resolution: "Client needs to send Astro-Authorization header",
                    errorLocation: __dirname
                });
                context.code = "IH401.1";
                return reject(errors.errorMapper(401, missingHeader));
            }
            getBearerToken(headers["astro-authorization"], context)
                .then((token: string) => {
                    this.verifyToken(token)
                        .then((user: any) => {
                            this.user = user;
                            this.id_token = token;
                            context.guid = this.getPwCGuid();
                            context.logMeta.guid = context.guid;
                            return resolve(context.guid);
                        }, (errorMessage: string) => {
                            return reject(errors.errorMapper(401, errorMessage));
                        });
                }, (err: any) => {
                    return reject(err);
                });
        });
    }

    /**
     * Verifies whether a token is valid.
     *
     * @param {string} token the token to verify
     * @returns {void} Returns the valid user credentials on success,
     * null on failure
     * @memberof IdamAuthenticator
     */
    public verifyToken(token: string) {
        return new Promise((resolve, reject) => {
            let decodedToken: any;
            let userClaims: any;
            const invalidCred = "Invalid credentials.";
            let errorMsg: string = invalidCred;
            if (!token) {
                return reject(errorMsg);
            }
            try {
                decodedToken = jwt.decode(token, { complete: true });
            } catch (error) {
                this.context.log.error(
                    "IH401.4 Error decoding Idam JWT", {
                        "code": "IH401.4",
                        "description": "Invalid JWT was sent",
                        "resolution": "Send a valid JWT",
                        "errorLocation": __dirname,
                        "error": `${error.stack || error.message || error}`,
                    });
                this.context.code = "IH401.4";
                return reject(errorMsg);
            }

            if (decodedToken) {
                try {
                    const tokenParameters: any = {
                        format: this.certFormat,
                        issuer: decodedToken.payload.iss,
                        algorithms: this.algorithm
                    };
                    userClaims = jwt.verify(token, this.cert, tokenParameters);
                    return resolve(userClaims);
                } catch (err) {
                    switch (err.constructor) {
                        case jwt.TokenExpiredError:
                            errorMsg = "Expired credentials.";
                            break;
                        case jwt.JsonWebTokenError:
                            errorMsg = invalidCred;
                            break;
                        case jwt.NotBeforeError:
                            errorMsg = "Credentials used before issuance time.";
                            break;
                        default:
                            errorMsg = invalidCred;
                            break;
                    }
                    this.context.log.error(
                        'IH401.5 Error verifying Idam JWT', {
                            "errorMessage": errorMsg,
                            "code": "IH401.5",
                            "description": "Invalid JWT was sent",
                            "resolution": "Send a valid JWT",
                            "errorLocation": __dirname,
                            "error": err.stack,
                        });
                    this.context.code = "IH401.5";
                    return reject(errorMsg);
                }
            } else {
                return reject(errorMsg);
            }
        });
    }

    /**
     * @returns {Object} User's verified claims from JWT.
     */
    public getUser() {
        return this.user;
    }

    /**
     * @returns {string} verified JWT/id_token
     */
    public getIdToken(): string {
        return this.id_token;
    }

    /**
     * @returns {string} verified pwc guid from JWT
     */
    public getPwCGuid(): string {
        return this.user[process.env.pwc_guid_schema as string];
    }

    /**
    * @returns {string} verified pwc employeeId from JWT
    */
    public getPwCEmployeeId(): string {
        return this.user[process.env.pwc_employeeid_schema as string];
    }

    /**
     * @returns {string} verified pwc email from JWT
     */
    public getEmail(): string {
        return this.user[process.env.pwc_email_schema as string];
    }

    /**
     * @returns {string} verified user's organization's country from JWT
     */
    public getOrganizationCountry(): string {
        return this.user[process.env.pwc_organization_schema as string];
    }
}
