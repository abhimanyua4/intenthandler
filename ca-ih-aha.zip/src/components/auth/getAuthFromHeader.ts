import { errors } from '../errors/errors';

/**
 * Extracts a token from a header with 'Bearer' grant_type.
 * @param {string} authorizationHeader the authorization header to extract the token from
 * @param {*} context the azure function context
 * 
 * @returns {Promise<token>} promise containing token on success
 */
export function getBearerToken(authorizationHeader: string, context: any): Promise<string> {
    return new Promise((resolve, reject) => {
        let parts;
        const malformedHeader = "Authorization header was malformed.";
        try {
            parts = authorizationHeader.split(' ');
            if (parts.length !== 2) {
                throw new Error(malformedHeader);
            }
        } catch (err) {
            context.log.error(
                'IH401.2 Malformed Authorization header', {
                    "errorMessage": "Error getting token from Authorization header.",
                    "code": "IH401.2",
                    "description": "Header didn't contain expected 'Authorization:Bearer token' format.",
                    "resolution": "Client needs to send header in expected format.",
                    "errorLocation": __dirname,
                    "error": err
                });
                context.code = "IH401.2";
            return reject(errors.errorMapper(401, malformedHeader));
        }
        const grantType = parts[0].trim();
        if (grantType.toLowerCase() !== 'bearer') {
            context.log.error(
                'IH401.3 Invalid grant_type', {
                    "errorMessage": "Invalid grant_type received",
                    "code": "IH401.3",
                    "description": "Header didn't contain expected 'bearer' grant_type",
                    "resolution": "Client needs to send expected 'bearer' grant_type",
                    "errorLocation": __dirname
                });
                context.code = "IH401.3";
            return reject(errors.errorMapper(401, 'invalid grant_type'));
        }

        const token = parts[1].trim();

        return resolve(token);
    });
}

/**
 * @description Extracts a token from a header with 'Bearer' grant_type.
 * 
 * @export
 * @param {string} authorizationHeader the authorization header to extract the token from
 * @param {*} context the azure function context
 * @returns {(null | string)} returns either the token or null
 */
export function getBearerTokenSync(authorizationHeader: string, context: any): null | string {
    let parts;
    const malformedHeader = "Authorization header was malformed.";
    try {
        parts = authorizationHeader.split(' ');
        if (parts.length !== 2) {
            throw new Error(malformedHeader);
        }
    } catch (err) {
        context.log.error(
            'IH401.2 Malformed Authorization header', {
                "errorMessage": "Error getting token from Authorization header.",
                "code": "IH401.2",
                "description": "Header didn't contain expected 'Authorization:Bearer token' format.",
                "resolution": "Client needs to send header in expected format.",
                "errorLocation": __dirname,
                "error": err
            });
        return null;
    }
    const grantType = parts[0].trim();
    if (grantType.toLowerCase() !== 'bearer') {
        context.log.error(
            'IH401.3 Invalid grant_type', {
                "errorMessage": "Invalid grant_type received",
                "code": "IH401.3",
                "description": "Header didn't contain expected 'bearer' grant_type",
                "resolution": "Client needs to send expected 'bearer' grant_type",
                "errorLocation": __dirname
            });
        return null;
    }

    return parts[1].trim(); // token
}
