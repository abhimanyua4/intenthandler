/**
 * Takes the certificate as a string and converts it into PKCS8 format.
 * Certificate must be in this specific format or else the jwt verify function won't accept it.
 *
 * @private
 * @param {*} context Azure functions context
 * @param {string} certificate The certificate to be formatted
 * @returns {(string | null)} the converted certificate on success, null on failure
 */
export function convertCertificate(
    context: any,
    certificate: string
): string | null {
    try {
        let cert = certificate;
        const beginCert = "-----BEGIN CERTIFICATE-----";
        const endCert = "-----END CERTIFICATE-----";
        cert = cert.replace("\n", "");
        cert = cert.replace(beginCert, "");
        cert = cert.replace(endCert, "");
        let result = beginCert;
        while (cert.length > 0) {
            if (cert.length > 64) {
                result += "\n" + cert.substring(0, 64);
                cert = cert.substring(64, cert.length);
            } else {
                result += "\n" + cert;
                cert = "";
            }
        }

        if (result[result.length] !== "\n") {
            result += "\n";
        }
        result += endCert + "\n";
        return result;
    } catch (err) {
        if (context) {
            context.log.error("ERROR CONVERTING CERTIFICATE", { "errorMesage": err.stack || err.message || err });
        }
    }
    return null;
}
