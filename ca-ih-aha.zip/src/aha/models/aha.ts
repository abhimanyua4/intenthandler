import { errors } from "../../components/errors/errors";
import { httpRequest, HTTPRequestOptions, BaseResponse } from 'astro-utilities';
export type Method = "DELETE" | "POST" | "PUT" | "GET";

export function ahaRequest(url: string, apiKey: string, method: Method, context: any, body?: any) {
    return new Promise((resolve, reject) => {

        const params = {
            "Accept": "application/json",
            'Content-Type': 'application/json',
            'access_token': apiKey
        };

        const options: HTTPRequestOptions = {
            method: method,
            url: url,
            params,
            data: body
        };

        httpRequest(context, options)
            .then((result: BaseResponse) => {
                if (options.method === "DELETE") {

                    if (!result.data) {
                        resolve("Delete Success");
                    } else {
                        if (typeof result.data === 'string') {
                            reject(JSON.parse(result.data));
                        } else {
                            reject(result.data);

                        }
                    }

                } else if (method === "POST" || method === "PUT" || method === "GET") {

                    if (result.data) {
                        resolve(result.data);
                    } else {
                        reject(errors["500_INTERNAL_SERVER_ERROR"]);
                    }

                } else {
                    reject(errors["500_INTERNAL_SERVER_ERROR"]);
                }

            }).catch((err: any) => {
                reject(err);
            });
    });

}
