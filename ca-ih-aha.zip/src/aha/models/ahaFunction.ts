import { ahaRequest } from './aha';
import { optionHandler } from "../middlewares/optionHandler";
import { errors } from "../../components/errors/errors";
export type Method = "DELETE" | "POST" | "PUT" | "GET";

export class Aha {

    private context: any;
    private apiKey: string;

    headers = {
        Accept: "application/json",
        "Content-Type": "application/json"
    };

    constructor(context: any, apiKey: string) {
        this.context = context;
        this.apiKey = apiKey;
    }

    public ideas(method: Method, body: Object | any, cb: Function) {

        let requestBody: any;

        if (method === "POST") {

            const description = body.idea;
            let name: string;

            if (description.length > 50) {
                name = description.substring(0, 50) + "...";
            } else {
                name = description;
            }
            requestBody = {
                product_id: process.env["AHA-PJR-ASTRO"],
                idea: {
                    name: name,
                    description: description,
                    created_by: body.created_by
                }
            }
        } else {
            requestBody = body;
        }

        const url: string | object = optionHandler(requestBody, method);

        if (typeof url !== "string") {
            cb(errors["400_BAD_REQUEST"], null);
        } else {
            ahaRequest(url as string, this.apiKey, method, this.context, requestBody).then((res: any) => {
                cb(null, res);
            }).catch((err: any) => {
                cb(err, null);
            });
        }
    }

    public products(cb: Function) {
        const url = process.env["AHA-URL"] + 'products';
        ahaRequest(url, this.apiKey, 'GET', this.context)
            .then((res: any) => {
                cb(null, res);
            }).catch((err: any) => {
                cb(err, null);
            });
    }
}
