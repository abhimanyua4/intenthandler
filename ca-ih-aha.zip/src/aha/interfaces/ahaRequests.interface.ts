import { BaseRequest } from 'astro-utilities';

export interface PutIdeaRequest extends BaseRequest {
    id: string;
    idea: PutIdeaSchema;
}

interface PutIdeaSchema {
    name: string;
    workflow_status: object;
    description: string | object;
    tags: Array<string>;
    categories: Array<string>;
    created_by: string;
    assigned_to_user: string;
    feature: string;
    initiative: string;
    master_feature: string;
    initial_votes: string;
    visibility: string;
    watchers: Array<Number>;
    custom_fields: object;
}

export interface DeleteIdeaRequest extends BaseRequest {
    id: string;
}

export interface GetIdeaRequest extends BaseRequest {
    q: string;
    spam: boolean;
    workflow_status: object;
    tag: string;
    duplicates: boolean;
    id: string;
    sort: string;
    created_since: Date;
    created_before: Date;
    product_id: string;
}

export interface PostIdeaRequest extends BaseRequest {
    idea: string;
}

export interface AhaRequest {
    getIdeas: GetIdeaRequest;
    postIdeas: PostIdeaRequest;
    updateIdeas: PutIdeaRequest;
    deleteIdeas: DeleteIdeaRequest;
}
