import { Aha } from '../models/ahaFunction';
import { callbackResult } from '../../components/commonFunctions/returnResults';

export class Controller {

    private context: any;
    private req: any;
    private apiKey: string;
    private body: any;
    public ahaFunction: Aha;
    private userEmail: string;
    /**
     * @constructor
     * @param context 
     * @param req 
     * @param accessToken 
     * @param body 
     */
    constructor(userEmail: string, context: any, req: any, apiKey: string, body: any) {
        this.context = context;
        this.req = req;
        this.apiKey = apiKey;
        this.body = body;
        this.ahaFunction = new Aha(this.context, this.apiKey);
        this.userEmail = userEmail;
    }

    /**
     * @name postIdeas
     * @description create an idea. name, description and product_id is required
     */
    public postIdeas() {
        this.body.created_by = this.userEmail;
        return this.ahaFunction.ideas('POST', this.body, callbackResult.bind(this, this.context));
    }

    /**
     * @name getIdeas
     * @description get all the ideas or ideas from a specific products or a specific idea
     */
    public getIdeas() {
        return this.ahaFunction.ideas('GET', this.body, callbackResult.bind(this, this.context));
    }

    /**
    * @name getProducts
    * @description get all the products or a specific products by given it's id or reference_prefix
    */
    public getProducts() {
        return this.ahaFunction.products(callbackResult.bind(this, this.context));
    }

    /**
     * @name updateIdeas
     * @description change the detail of specify idea, id is required
     */
    public updateIdeas() {
        return this.ahaFunction.ideas('PUT', this.body, callbackResult.bind(this, this.context));
    }

    /**
     * @name deleteIdeas
     * @description delete a specify idea, id is required
     */
    public deleteIdeas() {
        return this.ahaFunction.ideas('DELETE', this.body, callbackResult.bind(this, this.context));
    }
}
