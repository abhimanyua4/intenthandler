const Joi = require("joi");

// Astro Modules
import {
  PostIdeaRequest,
  GetIdeaRequest,
  PutIdeaRequest,
  DeleteIdeaRequest, 
  AhaRequest
} from "../interfaces/ahaRequests.interface";
import { baseRequestSchema } from 'astro-utilities';

export const reqPostIdeas: PostIdeaRequest = {
  ...baseRequestSchema,
  idea: Joi.string().trim().regex(/[0-9a-zA-Z]/).required()
};

export const reqGetIdea: GetIdeaRequest = {
  ...baseRequestSchema,
  q: Joi.string().trim().regex(/[0-9a-zA-Z]/),
  spam: Joi.boolean(),
  workflow_status: Joi.object().keys({
    id: Joi.string().trim().regex(/[0-9]/),
    name: Joi.string().trim().regex(/[0-9a-zA-Z]/),
    position: Joi.number().optional(),
    complete: Joi.boolean(),
    color: Joi.string().trim().regex(/^#[A-Fa-f0-9]{6}/)
  }),
  tag: Joi.string().trim().regex(/[0-9a-zA-Z]/),
  duplicates: Joi.boolean(),
  id: Joi.string().trim().regex(/[0-9]/),
  sort: Joi.string().trim().regex(/[0-9a-zA-Z]/),
  created_since: Joi.date().iso(),
  created_before: Joi.date().iso(),
  product_id: Joi.string().trim().regex(/[0-9a-zA-Z]/)
};

export const reqPutIdea: PutIdeaRequest = {
  ...baseRequestSchema,
  id: Joi.string().trim().regex(/[0-9a-zA-Z]/).required(),
  idea: Joi.object().keys({
    name: Joi.string().trim().regex(/[0-9a-zA-Z]/),
    workflow_status: Joi.object().keys({
      id: Joi.string().trim().regex(/[0-9]/),
      name: Joi.string().trim().regex(/[0-9a-zA-Z]/),
      position: Joi.number().optional(),
      complete: Joi.boolean(),
      color: Joi.string().trim().regex(/^#[A-Fa-f0-9]{6}/)
    }),
    description: Joi.alternatives(
      Joi.string().trim().regex(/[0-9a-zA-Z]/),
      Joi.object().keys({
        id: Joi.string().trim().regex(/[0-9]/),
        body: Joi.string().trim().regex(/[0-9a-zA-Z]/),
        created_at: Joi.date().iso(),
        attachments: Joi.array()
      })
    ),
    tags: Joi.array(),
    categories: Joi.array(),
    created_by: Joi.string().trim().regex(/[0-9a-zA-Z]/),
    assigned_to_user: Joi.string().trim().regex(/[0-9a-zA-Z]/),
    feature: Joi.string().trim().regex(/[0-9a-zA-Z]/),
    initiative: Joi.string().trim().regex(/[0-9a-zA-Z]/),
    master_feature: Joi.string().trim().regex(/[0-9a-zA-Z]/),
    initial_votes: Joi.string().trim().regex(/[0-9a-zA-Z]/),
    visibility: Joi.string().trim().regex(/[0-9a-zA-Z]/),
    watchers: Joi.alternatives(
      Joi.array().items(Joi.string().trim().regex(/[0-9]/)),
      Joi.string().trim().regex(/[0-9,]/)
    ),
    custom_fields: Joi.object()
  })
};

export const reqDeleteIdea: DeleteIdeaRequest = {
  ...baseRequestSchema,
  id: Joi.string().trim().regex(/[0-9]/).required()
};

/**
 * The schema to send with switchFunctionWithJoiValidation function
 */
export const ahaRequestSchema: AhaRequest = {
  getIdeas: reqGetIdea,
  postIdeas: reqPostIdeas,
  updateIdeas: reqPutIdea,
  deleteIdeas: reqDeleteIdea
};
