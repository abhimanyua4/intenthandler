// import {
//   GetIdeaRequest,
//   PostIdeaRequest
// } from "../interfaces/aha/aha.requests.interface";

//import { GetIdeaRequest, PostIdeaRequest } from '../interfaces/aha/aha-interface';
import { errors } from "../../components/errors/errors";

interface GetIdeaRequest {
  [key: string]: any;
}

interface PostIdeaRequest {
  [key: string]: any;
}

export function optionHandler(
  body: GetIdeaRequest | PostIdeaRequest,
  method: string
): string | object {
  let url: string = process.env["AHA-URL"] as string;
  if (method === "GET") {
    if (body.product_id) {
      url = url + "products/" + body.product_id;
    }
    if (body.id) {
      url = url + "ideas/" + body.id;
    } else {
      if (body.product_id) {
        url = url + "/ideas";
      } else {
        url = url + "ideas";
      }
    }
  }

  if (method === "POST") {
    if (body.product_id) {
      url = url + "products/" + body.product_id + "/ideas";
    } else {
      return "";
    }
  }

  if (method === "PUT") {
    if (body.id) {
      url = url + "ideas/" + body.id;
    } else {
      return "";
    }
  }
  if (method === "DELETE") {
    if (body.id) {
      url = url + "ideas/" + body.id;
    } else {
      return "";
    }
  }

  if (url !== (process.env["AHA-URL"] as string)) {
    return url;
  } else {
    return errors["400_BAD_REQUEST"];
  }
}
