import { IdamAuthenticator } from '../components/auth/idamAuth';
import { Bootstrap } from '../components';
import { Controller } from "./controllers/controller";
import { returnBadRequest, returnUnauthorized } from '../components/commonFunctions/returnResults';
import { errors } from '../components/errors/errors';
import { switchFunctionWithJoiValidation } from '../components/commonFunctions/switchFunction';
import { ahaRequestSchema } from './middlewares/requestSchema';
import { standardErrors } from '../components/errors/ihErrors';
import { standardLog } from '../components/constant/logMessages';
module.exports = function run(context: any, req: any) {
    // function {name} started
    
    context.timer = setTimeout(() => {
        return returnBadRequest(context, errors["408_TIMEOUT"]);
    }, 30000);

    Bootstrap.start(context);

    const authenticator = new IdamAuthenticator(context);

    authenticator.platformAuthorization(req.headers, context)
        .then((guid: any) => {

            // authenticated (maybe this log needs to go in authenticator.platformAuthorization)

            if (req.body && (req.params.action || req.body.action)) {
                context.log.info(`${context.executionContext.functionName} Request Body Received`, standardLog.mapper("requestReceived"));
                const userEmail = authenticator.getEmail();

                const apiKey: string = req.headers.apikey || process.env["AHA-API-KEY"] as string;
                const action = req.params.action || req.body.action;
                
                const controller = new Controller(userEmail, context, req, apiKey, req.body);
                return switchFunctionWithJoiValidation(context, controller, ahaRequestSchema);
                
            } else {
                context.log.error(`${context.executionContext.functionName} Error`, standardErrors.mapper("IH400.2"));
                returnBadRequest(context, errors['400_BAD_REQUEST']);
            }
        }, (err) => {
            return returnUnauthorized(context, err);
        });
};
