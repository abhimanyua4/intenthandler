module.exports = function (grunt) {
    'use strict',

    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        ts: {
            options: {
                rootDir: 'src'
            },
            dev: {
                src: ['src/**/*.ts', '!node_modules/**/*.ts', '!tests/**/*'],
                outDir: 'bin',
                watch: 'src',
                options: {
                    module: 'commonjs',
                    target: 'es2015'
                }
            },
            VSTS: {
                src: ['src/**/*.ts', '!node_modules/**/*.ts', '!tests/**/*'],
                outDir: 'bin',
                options: {
                    module: 'commonjs',
                    target: 'es2015',
                    fast: 'never'
                }
            }
        },
        sync: {
            dev: {
                files: [{
                    cwd: 'src',
                    src: [
                        '**', /* Include everything */
                        '!**/*.ts' /* but exclude ts files */                        
                    ],
                    dest: 'bin',
                }],
                verbose: true // Display log messages when copying files
            },
            VSTS: {
                files: [{
                    cwd: 'src',
                    src: [
                        '**', /* Include everything */
                        '!**/*.ts', /* but exclude ts files */
                        '!local.settings.json'
                    ],
                    dest: 'bin',
                }],
                verbose: true // Display log messages when copying files
            }
        },
        exec: {}
    });
    grunt.loadNpmTasks('grunt-ts');
    grunt.loadNpmTasks('grunt-sync');

    //for all tasks underneath type grunt [taskname] in command line

    // if you need to copy any and all non .ts files
    grunt.registerTask('copy', 'sync:dev');

    // local development: copies all non .ts files to bin and transpiles all .ts files to .js
    grunt.registerTask('default', ['sync:dev', 'ts:dev']);

    // build on VSTS/for azure: copies all non .ts files to bin(except for local.settings.json)
    // and transpiles all .ts files to .js
    grunt.registerTask('build', ['sync:VSTS', 'ts:VSTS']);
};