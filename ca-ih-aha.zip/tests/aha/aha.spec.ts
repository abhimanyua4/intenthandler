import { expect } from 'chai';
import { Controller } from '../../src/aha/controllers/controller';
import { switchFunctionWithInputValidation, switchFunction, switchFunctionWithJoiValidation } from '../../src/components/commonFunctions/switchFunction';
import { getProductsMockData, getIdeasMockData, postIdeasMockData } from './ahaMockData';
import { ahaRequestSchema } from '../../src/aha/middlewares/requestSchema';

const MockAdapter = require('axios-mock-adapter');
const axios = require('axios');

let logStub: any = {};
logStub.log = () => { };
logStub.log.verbose = () => { };
logStub.log.warn = () => { };
logStub.log.info = () => { };
logStub.log.error = () => { };
logStub.log.debug = () => { };
logStub = logStub.log;

describe("aha core integration funcitonality", () => {

    process.env["NODE-ENV"] = "local";
    process.env["AHA-API-KEY"] = "6c07c162472839b94c5bc56aae885656053237df88a0a60c208f9eed29de2504";
    process.env["AHA-URL"] = "https://pwc.aha.io/api/v1/";

    it("Should return success from aha/getProducts", (done: any) => {
        const mock = new MockAdapter(axios);
        mock.onGet("https://pwc.aha.io/api/v1/products").reply(200, getProductsMockData);
        const context: any = {
            res: {
                status: null
            },
            req: {
                body: {
                    action: 'getProducts'
                },
            },
            executionContext: {
                functionName : "aha"
            },
            
            done: () => {
                expect(context.res.status).to.be.equal(200);
                mock.reset();
                mock.restore();
                done();
            },
            log: logStub
        };

        const apiKey = process.env["AHA-API-KEY"] as string;
        const controller = new Controller("jia.qi.lin@pwc.com", context, {}, apiKey, context.req.body);
        switchFunctionWithJoiValidation(context, controller, ahaRequestSchema);
    });

    it("Should return success from aha/getIdeas with valid id", (done: any) => {
        const mock = new MockAdapter(axios);
        mock.onGet("https://pwc.aha.io/api/v1/ideas/6654621389354779778").reply(200, getIdeasMockData);
        const context: any = {
            res: {
                status: null
            },
            req: {
                body: {
                    action: 'getIdeas',
                    id: "6654621389354779778"
                },

            },
            executionContext: {
                functionName : "aha"
            },
            done: () => {
                expect(context.res.status).to.be.equal(200);
                mock.reset();
                mock.restore();
                done();
            },
            log: logStub
        };
        const apiKey = process.env["AHA-API-KEY"] as string;
        const controller = new Controller("jia.qi.lin@pwc.com", context, {}, apiKey, context.req.body);
        switchFunctionWithJoiValidation(context, controller, ahaRequestSchema);
    });

    it("Should return 400 from aha/postIdeas with invalid schema", (done: any) => {
        const mock = new MockAdapter(axios);
        mock.onGet("https://pwc.aha.io/api/v1/products").reply(200, getProductsMockData);
        const context: any = {
            res: {
                status: null
            },
            req: {
                body: {
                    product_id: "Invalid product id",
                    idea: {
                        invalid: "New Idea",
                        invaild2: "This is a description"
                    }
                },

            },
            executionContext: {
                functionName : "aha"
            },
            done: () => {
                expect(context.res.status).to.be.equal(400);
                mock.reset();
                mock.restore();
                done();
            },
            log: logStub
        };
        const apiKey = process.env["AHA-API-KEY"] as string;
        const controller = new Controller("jia.qi.lin@pwc.com", context, {}, apiKey, context.req.body);
        switchFunctionWithJoiValidation(context, controller, ahaRequestSchema);
    });

    it("Should return 400 from aha/updateIdeas with invalid id", (done: any) => {
        const mock = new MockAdapter(axios);
        mock.onGet("https://pwc.aha.io/api/v1/ideas/999999999999999999999999999999999999999999").reply(400, {});
        const context: any = {
            res: {
                status: null
            },
            req: {
                body: {
                    id: "999999999999999999999999999999999999999999",
                    idea: {
                        neme: "New Idea",
                        description: "This is a description"
                    }
                },

            },
            executionContext: {
                functionName : "aha"
            },
            done: () => {
                expect(context.res.status).to.be.equal(400);
                mock.reset();
                mock.restore();
                done();
            },
            log: logStub
        };
        const apiKey = process.env["AHA-API-KEY"] as string;
        const controller = new Controller("jia.qi.lin@pwc.com", context, {}, apiKey, context.req.body);
        switchFunctionWithJoiValidation(context, controller, ahaRequestSchema);
    });

    it("Should return 200 from aha/updateIdeas with valid id", (done: any) => {
        const mock = new MockAdapter(axios);
        mock.onPut("https://pwc.aha.io/api/v1/ideas/6686291667078756132").reply(200, postIdeasMockData);
        const context: any = {
            res: {
                status: null
            },
            req: {
                body: {
                    action: 'updateIdeas',
                    id: "6686291667078756132",
                    idea: {
                        name: "New Idea new",
                        description: "This is a new description"
                    }
                },
            },
            executionContext: {
                functionName : "aha"
            },
            done: () => {
                expect(context.res.status).to.be.equal(200);
                mock.reset();
                mock.restore();
                done();
            },
            log: logStub
        };
        const apiKey = process.env["AHA-API-KEY"] as string;
        const controller = new Controller("jia.qi.lin@pwc.com", context, {}, apiKey, context.req.body);
        switchFunctionWithJoiValidation(context, controller, ahaRequestSchema);
    });

    it("Should fail and return 400 from aha/updateIdeas with valid id but invalid schema", (done: any) => {
        const mock = new MockAdapter(axios);

        mock.onPut("https://pwc.aha.io/api/v1/ideas/6686291667078756132").reply(200, postIdeasMockData);

        const context: any = {
            res: {
                status: null
            },
            req: {
                body: {
                    id: "6686291667078756132",
                    idea: {
                        invalid: "New Idea new",
                        invalid2: "This is a new description"
                    }
                },

            },
            executionContext: {
                functionName : "aha"
            },
            done: () => {
                expect(context.res.status).to.be.equal(400);
                mock.reset();
                mock.restore();
                done();
            },
            log: logStub
        };
        const apiKey = process.env["AHA-API-KEY"] as string;
        const controller = new Controller("jia.qi.lin@pwc.com", context, {}, apiKey, context.req.body);
        switchFunctionWithJoiValidation(context, controller, ahaRequestSchema);
    });

});
