export const getProductsMockData = {
    "products": [
        {
            "id": "6578873265979498635",
            "reference_prefix": "ASTRO",
            "name": "Project Astro",
            "product_line": true,
            "created_at": "2018-07-16T17:48:17.032Z"
        },
        {
            "id": "6578873358307635772",
            "reference_prefix": "PRJASTRO",
            "name": "Project Astro",
            "product_line": false,
            "created_at": "2018-07-16T17:48:38.530Z"
        }
    ],
    "pagination": {
        "total_records": 2,
        "total_pages": 1,
        "current_page": 1
    }
};

export const postIdeasMockData = {
    "idea": {
        "id": "58056975",
        "name": "Idea 1",
        "reference_num": "PRJ1-I-1",
        "score": 15,
        "created_at": "2019-02-06T01:47:32.000Z",
        "updated_at": "2019-02-06T01:48:04.856Z",
        "product_id": 131414752,
        "votes": 0,
        "workflow_status": {
            "id": "3259216",
            "name": "New",
            "position": 1,
            "complete": false,
            "color": "#dce7c6"
        },
        "description": {
            "id": "103757394",
            "body": "Description of idea 1",
            "created_at": "2019-02-06T01:47:32.000Z",
            "attachments": []
        },
        "visibility": "Visible to all ideas portal users",
        "url": "http://account1.example.org/ideas/ideas/PRJ1-I-1",
        "resource": "http://account1.example.org/api/v1/ideas/PRJ1-I-1",
        "product": {
            "id": "131414752",
            "reference_prefix": "PRJ1",
            "name": "Project 1",
            "product_line": false,
            "created_at": "2019-02-06T01:47:32.000Z"
        },
        "created_by_user": {
            "id": "1020675218",
            "name": "Mary Humpty",
            "email": "mary.humpty@account1.com",
            "created_at": "2019-02-06T01:47:31.000Z",
            "updated_at": "2019-02-06T01:48:04.859Z"
        },
        "assigned_to_user": null,
        "endorsements_count": 1, "comments_count": 0,
        "score_facts": [{
            "id": "244026645",
            "value": 10,
            "name": "Effort"
        },
        {
            "id": "394452137",
            "value": 5, "name": "Benefit"
        }],
        "tags": ["Infrastructure"],
        "full_tags": [{
            "id": 775582684,
            "name": "Infrastructure",
            "color": "#7552e0"
        }],
        "categories": [{
            "id": "972845454",
            "name": "Hard disk drive",
            "parent_id": 552935478,
            "created_at": "2019-02-06T01:47:31.000Z"
        }],
        "custom_fields": [{
            "key": "priority",
            "name": "Priority",
            "value": "P3",
            "type": "string"
        },
        {
            "key": "component",
            "name": "Component",
            "value": "web",
            "type": "array"
        }, {
            "key": "custom_scorecard_definition",
            "name": "Some custom scorecard definition",
            "value": 11,
            "type": "scorecard",
            "score_facts": [{
                "id": "84642379",
                "value": 10,
                "name": "Effort"
            }]
        }], "custom_object_links": [{
            "key": "customers_table",
            "name": "Customers for custom table",
            "record_type": "CustomObjectRecord",
            "record_ids": []
        }]
    }
}

export const getIdeasMockData = {
    "ideas": [
        {
            "id": "1055237874",
            "reference_num": "PRJ1-I-3",
            "name": "Idea 3 Merged",
            "created_at": "2019-02-06T01:47:32.000Z",
            "workflow_status": {
                "id": "1009437757",
                "name": "In progress",
                "position": 2,
                "complete": false,
                "color": "#ecdd8f"
            },
            "description": {
                "id": "506957205",
                "body": "Description of idea 3",
                "created_at": "2019-02-06T01:47:32.000Z",
                "attachments": []
            },
            "url": "http://account1.example.org/ideas/ideas/PRJ1-I-3",
            "resource": "http://account1.example.org/api/v1/ideas/PRJ1-I-3"
        },
        {
            "id": "444379319",
            "reference_num": "PRJ1-I-2",
            "name": "Idea 2",
            "created_at": "2019-02-06T01:47:32.000Z",
            "workflow_status": {
                "id": "1009437757",
                "name": "In progress",
                "position": 2,
                "complete": false,
                "color": "#ecdd8f"
            },
            "description": {
                "id": "378547141",
                "body": "Description of idea 2",
                "created_at": "2019-02-06T01:47:32.000Z",
                "attachments": []
            },
            "url": "http://account1.example.org/ideas/ideas/PRJ1-I-2",
            "resource": "http://account1.example.org/api/v1/ideas/PRJ1-I-2"
        },
    ],
    "pagination": {
        "total_records": 2,
        "total_pages": 1,
        "current_page": 1
    }
};
